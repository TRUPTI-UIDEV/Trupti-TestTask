import './App.css';
import Carlist from './Carlist';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Carlist/>
      </header>
    </div>
  );
}

export default App;
